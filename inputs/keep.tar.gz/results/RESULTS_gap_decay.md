# Wie schnell schließt sich die Lücke? (Minutendaten)

131 Stufen mit Minutendaten, 9 Wochen. Kosten 0.02 je Anteil (bei Auflösung nur halbe Kosten). Fairer Wert: DVOL x 0.858.

## Schwelle 0.05

|   Reaktion (Min.) |   Ereignisse |   übrige Lücke (Median) |   PnL Ausstieg +60 Min. |       t |   PnL bis Auflösung |     t  |
|------------------:|-------------:|------------------------:|------------------------:|--------:|--------------------:|-------:|
|                 0 |         1573 |                  1      |                  0.0073 |  1.6347 |              0.1189 | 3.2079 |
|                 1 |         1573 |                  0.985  |                 -0.0039 | -0.4707 |              0.1075 | 2.8833 |
|                 2 |         1573 |                  0.9154 |                 -0.0113 | -3.0393 |              0.0998 | 2.628  |
|                 5 |         1570 |                  0.8797 |                 -0.0134 | -5.6025 |              0.0976 | 2.449  |
|                10 |         1569 |                  0.8527 |                 -0.0141 | -6.654  |              0.097  | 2.4251 |
|                15 |         1569 |                  0.8405 |                 -0.0159 | -5.0488 |              0.0958 | 2.4181 |
|                30 |         1561 |                  0.8194 |                 -0.0168 | -5.3788 |              0.0923 | 2.2138 |
|                60 |         1556 |                  0.7828 |                 -0.0159 | -2.8676 |              0.0927 | 2.1878 |

**Lücken nach Alter der letzten Polymarket-Kursmeldung (sofortiger Einstieg)** — große Lücken bei alten Meldungen = vermutlich nur fehlende Daten, nicht handelbar

| Kursmeldung vor   |    n |   PnL60 |   PnL_Ende |
|:------------------|-----:|--------:|-----------:|
| ≤1 Min            | 1566 |  0.0071 |     0.1187 |
| 2-5               |    7 |  0.0439 |     0.1549 |

## Schwelle 0.10

|   Reaktion (Min.) |   Ereignisse |   übrige Lücke (Median) |   PnL Ausstieg +60 Min. |       t |   PnL bis Auflösung |     t  |
|------------------:|-------------:|------------------------:|------------------------:|--------:|--------------------:|-------:|
|                 0 |          467 |                  1      |                  0.059  |  4.8042 |              0.2284 | 4.1844 |
|                 1 |          466 |                  0.9648 |                  0.0202 |  2.4065 |              0.1894 | 3.4968 |
|                 2 |          466 |                  0.9039 |                  0.0042 |  0.7436 |              0.1732 | 3.0854 |
|                 5 |          465 |                  0.8373 |                 -0.0005 | -0.0377 |              0.1652 | 2.9115 |
|                10 |          463 |                  0.8179 |                 -0.009  | -1.2008 |              0.1598 | 2.8478 |
|                15 |          463 |                  0.7995 |                 -0.009  | -0.7513 |              0.1581 | 2.8978 |
|                30 |          460 |                  0.7689 |                 -0.0004 | -0.5    |              0.1579 | 2.8573 |
|                60 |          458 |                  0.7466 |                  0.0025 | -0.614  |              0.1526 | 2.7447 |

**Lücken nach Alter der letzten Polymarket-Kursmeldung (sofortiger Einstieg)** — große Lücken bei alten Meldungen = vermutlich nur fehlende Daten, nicht handelbar

| Kursmeldung vor   |   n |   PnL60 |   PnL_Ende |
|:------------------|----:|--------:|-----------:|
| ≤1 Min            | 464 |  0.0581 |     0.2288 |
| 2-5               |   3 |  0.1867 |     0.1667 |

## Lesehilfe

- Fällt der PnL schon bei 1–2 Min. Reaktion auf ~0 → nur für schnelle Bots nutzbar.
- Bleibt er bei 5–15 Min. deutlich positiv (t > 2) → mit einem einfachen automatisierten Ansatz machbar.
- Gewinne nur bei alten Kursmeldungen (>15 Min.) → Datenartefakt (kein aktueller Preis vorhanden).
